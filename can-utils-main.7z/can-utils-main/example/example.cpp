#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <random>
#include <bit>

#include "dbc/dbc_parser.h"
#include "v2c/v2c_transcoder.h"

std::string read_file(const std::string& dbc_path) {
    std::ifstream dbc_content(dbc_path);
    std::ostringstream ss;
    ss << dbc_content.rdbuf();
    return ss.str();
}

// Generates a single CAN frame with predefined data and ID
can_frame generate_frame() {
    can_frame frame;
   
    unsigned char frame_data[8] = {10, 170, 0, 0, 255, 0, 0, 0}; 
    std::memcpy(frame.data, frame_data, 8);
    frame.can_id = 1962;
    return frame;
}

// Decodes and displays a single CAN frame
void decode_and_display_frame(const can_frame& frame, can::v2c_transcoder& transcoder) {
    using namespace std::chrono;

    // Simulate timestamp for the frame
    auto timestamp = std::chrono::system_clock::now();
    double t = duration_cast<milliseconds>(timestamp.time_since_epoch()).count() / 1000.0;

    // Display basic frame information
    std::cout << std::fixed
              << "Decoded CAN frame at t: " << t << "s\n"
              << "  CAN ID: " << frame.can_id << "\n"
              << "  Data: 0x" << std::hex << std::bit_cast<int64_t>(frame.data) << std::dec << "\n";

    // Find and decode message using the transcoder
    auto msg = transcoder.find_message(frame.can_id);
    if (msg) {
        auto frame_data = std::bit_cast<int64_t>(frame.data);
        for (const auto& sig : msg->signals(frame_data)) {
            std::cout << "  Signal " << sig.name() << ": " << static_cast<int64_t>(sig.decode(frame_data)) << "\n";
        }
    } else {
        std::cout << "  No message definition found for CAN ID: " << frame.can_id << "\n";
    }
}

int main() {
    can::v2c_transcoder transcoder;

    // Parse the DBC file
    auto start = std::chrono::system_clock::now();
    bool parsed = can::parse_dbc(read_file("example/example.dbc"), std::ref(transcoder));
    if (!parsed) {
        std::cerr << "Failed to parse DBC file." << std::endl;
        return 1;
    }
    auto end = std::chrono::system_clock::now();
    std::cout << "Parsed DBC in "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count()
              << "ms\n";

    // Generate a single CAN frame
    can_frame frame = generate_frame();

    // Decode and display the frame
    decode_and_display_frame(frame, transcoder);

    return 0;
}
